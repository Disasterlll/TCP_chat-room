#ifndef CLIENTMANAGER_H
#define CLIENTMANAGER_H

#include "Protocol.h"

#include <QObject>
#include <QTcpSocket>

class ClientController : public QObject
{
    Q_OBJECT
public:

    explicit ClientController(QHostAddress ip = QHostAddress::LocalHost, ushort port = 4500, QObject *parent = nullptr);
    void connectToServer();
    void sendName(QString name);
    void sendMessage(QString message, QString receiver);
    void sendInitSendingFile(QString fileName);
    void sendAcceptFile();
    void sendRejectFile();

signals:

    void connected();
    void disconnected();
//    void dataReceived(QByteArray data);
    void textMessageReceived(QString message);
    void nameChanged(QString name);
    void rejectReceivingFile();
    void initReceivingFile(QString clientName, QString fileName, qint64 fileSize);
    void connectionACK(QString myName, QStringList clientsName);
    void newClientConnectedToServer(QString clienName);
    void clientNameChanged(QString prevName, QString clientName);
    void clientDisconnected(QString clientName);

private slots:

    void readyRead();

private: 

    QTcpSocket *socket;
    QHostAddress ip;
    ushort port;
    Protocol protocol;
    QString tmpFileName;

private: 

     void setupClient();
     void sendFile();
};

#endif // CLIENTMANAGER_H
