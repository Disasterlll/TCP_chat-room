#ifndef CHATPROTOCOL_H
#define CHATPROTOCOL_H

#include <QByteArray>
#include <QString>
#include <QStringList>


class Protocol
{
public:

    enum MessageType{
        Text,
        Name,
        FileSendRequest,
        AcceptSendingFile,
        RejectSendingFile,
        SendFile,
        ClientName,
        ConnectionACK,
        NewClient,
        ClientDisconnected
    };

    Protocol();

    QByteArray SetText(QString message, QString receiver);
    QByteArray setName(QString name);
    QByteArray setFileSendRequest(QString fileName);
    QByteArray setAcceptFile();
    QByteArray setRejectFile();
    QByteArray setFile(QString fileName);
    void loadData(QByteArray data);
    const QString &getMessage() const;
    const QString &getName() const;
    MessageType getType() const;
    const QString &getFileName() const;
    qint64 getFileSize() const;
    const QByteArray &getFileData() const;
    QString getReceiver() const;
    const QString &getClientName() const;
    const QString &getPrevName() const;
    const QStringList &getClientsName() const;
    const QString &getMyName() const;

private:

    QByteArray getData(MessageType type, QString data);
    MessageType type;
    QString message;
    QString name;
    QString fileName;
    qint64 fileSize;
    QByteArray fileData;
    QString receiver;
    QString clientName;
    QString prevName;
    QStringList clientsName;
    QString myName;

};

#endif
