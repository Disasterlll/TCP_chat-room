#include "SendReceive.h"

ClientController::ClientController(QHostAddress ip, ushort port, QObject *parent)
    : QObject{parent},
      ip(ip),
      port(port)
{
    setupClient();
}

void ClientController::connectToServer()
{
    socket->connectToHost(ip, port);
}

void ClientController::sendName(QString name)
{
    socket->write(protocol.setName(name));
}

void ClientController::sendMessage(QString message, QString receiver)
{
    socket->write(protocol.SetText(message, receiver));
}


void ClientController::sendInitSendingFile(QString fileName)
{
    tmpFileName = fileName;
    socket->write(protocol.setFileSendRequest(fileName));
}

void ClientController::sendAcceptFile()
{
    socket->write(protocol.setAcceptFile());

}

void ClientController::sendRejectFile()
{
    socket->write(protocol.setRejectFile());

}

void ClientController::readyRead()
{
    auto data = socket->readAll();
    protocol.loadData(data);
    switch (protocol.getType()) {
    case Protocol::Text:
        emit textMessageReceived(protocol.getMessage());
        break;
    case Protocol::Name:
        emit nameChanged(protocol.getName());
        break;
    case Protocol::FileSendRequest:
        emit initReceivingFile(protocol.getName(), protocol.getFileName(), protocol.getFileSize());
        break;
    case Protocol::AcceptSendingFile:
        sendFile();
        break;
    case Protocol::RejectSendingFile:
        emit rejectReceivingFile();
        break;

    case Protocol::ConnectionACK:
        emit connectionACK(protocol.getMyName(), protocol.getClientsName());
        break;
    case Protocol::NewClient:
        emit newClientConnectedToServer(protocol.getClientName());
        break;
    case Protocol::ClientDisconnected:
        emit clientDisconnected(protocol.getClientName());
        break;
    case Protocol::ClientName:
        emit clientNameChanged(protocol.getPrevName(), protocol.getClientName());
        break;
    default:
        break;
    }
}

void ClientController::setupClient()
{
    socket = new QTcpSocket(this);
    connect(socket, &QTcpSocket::connected, this, &ClientController::connected);
    connect(socket, &QTcpSocket::disconnected, this, &ClientController::disconnected);
    connect(socket, &QTcpSocket::readyRead, this, &ClientController::readyRead);
}

void ClientController::sendFile()
{
    socket->write(protocol.setFile(tmpFileName));
}



