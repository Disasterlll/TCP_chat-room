/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionConnect;
    QAction *actionExot;
    QWidget *centralwidget;
    QListWidget *lstMessages;
    QPushButton *btnSendFile;
    QLineEdit *lnMessage;
    QComboBox *cmbDestination;
    QPushButton *btnSend;
    QLineEdit *lnClientName;
    QMenuBar *menubar;
    QMenu *menuOptions;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(615, 517);
        actionConnect = new QAction(MainWindow);
        actionConnect->setObjectName("actionConnect");
        actionExot = new QAction(MainWindow);
        actionExot->setObjectName("actionExot");
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        centralwidget->setEnabled(false);
        lstMessages = new QListWidget(centralwidget);
        lstMessages->setObjectName("lstMessages");
        lstMessages->setGeometry(QRect(9, 0, 591, 401));
        btnSendFile = new QPushButton(centralwidget);
        btnSendFile->setObjectName("btnSendFile");
        btnSendFile->setGeometry(QRect(570, 440, 35, 24));
        btnSendFile->setMaximumSize(QSize(35, 16777215));
        lnMessage = new QLineEdit(centralwidget);
        lnMessage->setObjectName("lnMessage");
        lnMessage->setGeometry(QRect(240, 440, 221, 22));
        cmbDestination = new QComboBox(centralwidget);
        cmbDestination->addItem(QString());
        cmbDestination->addItem(QString());
        cmbDestination->setObjectName("cmbDestination");
        cmbDestination->setGeometry(QRect(490, 410, 61, 22));
        btnSend = new QPushButton(centralwidget);
        btnSend->setObjectName("btnSend");
        btnSend->setGeometry(QRect(480, 440, 75, 24));
        lnClientName = new QLineEdit(centralwidget);
        lnClientName->setObjectName("lnClientName");
        lnClientName->setGeometry(QRect(240, 410, 111, 22));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 615, 22));
        menuOptions = new QMenu(menubar);
        menuOptions->setObjectName("menuOptions");
        MainWindow->setMenuBar(menubar);

        menubar->addAction(menuOptions->menuAction());
        menuOptions->addAction(actionConnect);
        menuOptions->addSeparator();
        menuOptions->addAction(actionExot);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Client", nullptr));
        actionConnect->setText(QCoreApplication::translate("MainWindow", "Connect", nullptr));
        actionExot->setText(QCoreApplication::translate("MainWindow", "Exit", nullptr));
        btnSendFile->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        lnMessage->setPlaceholderText(QCoreApplication::translate("MainWindow", "Type Message...", nullptr));
        cmbDestination->setItemText(0, QCoreApplication::translate("MainWindow", "Server", nullptr));
        cmbDestination->setItemText(1, QCoreApplication::translate("MainWindow", "All", nullptr));

        cmbDestination->setPlaceholderText(QString());
        btnSend->setText(QCoreApplication::translate("MainWindow", "Send", nullptr));
        lnClientName->setPlaceholderText(QCoreApplication::translate("MainWindow", "Enter Name...", nullptr));
        menuOptions->setTitle(QCoreApplication::translate("MainWindow", "Options", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
