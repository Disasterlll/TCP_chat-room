#include "Protocol.h"

#include <QFileInfo>
#include <QIODevice>

Protocol::Protocol()
{
}

QByteArray Protocol::SetText(QString message, QString receiver)
{
    QByteArray ba;
    QDataStream out(&ba, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_6_0);
    out << Text << receiver << message;
    return ba;
}


QByteArray Protocol::setFileSendRequest(QString fileName)
{
    QByteArray ba;
    QDataStream out(&ba, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_6_0);
    QFileInfo info(fileName);
    out << FileSendRequest << info.fileName() << info.size();
    return ba;
}

QByteArray Protocol::setName(QString name)
{
    return getData(Name, name);
}

QByteArray Protocol::setAcceptFile()
{
    return getData(AcceptSendingFile, "");

}

QByteArray Protocol::setRejectFile()
{
    return getData(RejectSendingFile, "");
}

QByteArray Protocol::setFile(QString fileName)
{
    QByteArray ba;
    QFile file(fileName);
    if (file.open(QIODevice::ReadOnly)) {
        QDataStream out(&ba, QIODevice::WriteOnly);
        out.setVersion(QDataStream::Qt_6_0);
        QFileInfo info(fileName);
        out << SendFile << info.fileName() << info.size() << file.readAll();
        file.close();
    }
    return ba;
}

QByteArray Protocol::getData(MessageType type, QString data)
{
    QByteArray ba;
    QDataStream out(&ba, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_6_0);
    out << type << data;
    return ba;
}



void Protocol::loadData(QByteArray data)
{
    QDataStream in(&data, QIODevice::ReadOnly);
    in.setVersion(QDataStream::Qt_6_0);
    in >> type;
    switch (type) {
    case Text:
        in >> receiver >> message;
        break;
    case Name:
        in >> name;
        break;
    case FileSendRequest:
        in >> fileName >> fileSize;
        break;
    case SendFile:
        in >> fileName >> fileSize >> fileData;
        break;
    case ClientName:
        in >> prevName >> clientName;
        break;
    case NewClient:
    case ClientDisconnected:
        in >> clientName;
        break;
    case ConnectionACK:
        in >> myName >> clientsName;
        break;
    default:
        break;
    }
}

const QString &Protocol::getMyName() const
{
    return myName;
}

const QStringList &Protocol::getClientsName() const
{
    return clientsName;
}

const QString &Protocol::getPrevName() const
{
    return prevName;
}

const QString &Protocol::getClientName() const
{
    return clientName;
}

QString Protocol::getReceiver() const
{
    return receiver;
}

const QByteArray &Protocol::getFileData() const
{
    return fileData;
}

qint64 Protocol::getFileSize() const
{
    return fileSize;
}

const QString &Protocol::getFileName() const
{
    return fileName;
}

Protocol::MessageType Protocol::getType() const
{
    return type;
}

const QString &Protocol::getName() const
{
    return name;
}

const QString &Protocol::getMessage() const
{
    return message;
}
